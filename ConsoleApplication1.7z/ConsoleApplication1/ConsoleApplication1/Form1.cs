﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApplication1
{
    public partial class Form1 : Action
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDormir_Click(object sender, EventArgs e)
        {
            this.sleep++;
        }
        private void btnmanger_Click(object sender, EventArgs e)
        {
            this.manger++;
        }
        private void btnNettoyer_Click(object sender, EventArgs e)
        {
            this.nettoyer++;
        }
        private void btnjouer_Click(object sender, EventArgs e)
        {
            this.jouer++;
        }
    }
}
