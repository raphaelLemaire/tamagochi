﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public abstract class Action // le tamagochi
    {
        protected int vie = 5;
        private Etat etat;
        protected char[] dessin;
        protected int sleep = 4;
        protected int nettoyer = 4;
        protected int manger = 4;
        protected int jouer = 4;
       
 

        public Etat Etat
        {
            get
            {
                return etat;
            }

            set
            {
                etat = value;
            }
        }
        public Action()
        {
            this.etat = Etat.OEUF;
            dessin = "01234".ToCharArray();
        }
        public void grandir()
        {
            this.etat++;
        }
        public override string ToString() 
        {
            char lettre = this.dessin[(int)this.etat]; 
            return lettre.ToString();  
        }

    }
    // boucle for toutes les 5 min sleep nettoyer manger dormir = --

}
