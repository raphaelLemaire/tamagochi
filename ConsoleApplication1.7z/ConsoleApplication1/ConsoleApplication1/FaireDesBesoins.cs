﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class FaireDesBesoins : Action
    {
        public FaireDesBesoins()
        : base()
        {
            if (this.nettoyer < 0)
            {
                this.vie++;
            }
            else if (this.nettoyer > 4)
            {
                this.vie--;
            }
        }
    }
}
