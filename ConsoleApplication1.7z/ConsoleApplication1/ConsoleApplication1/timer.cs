﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Threading;
namespace ConsoleApplication1
{
    class Timer
       
    {
        Timer t = new Timer();

        public Timer()
        {

        }
    }
}
