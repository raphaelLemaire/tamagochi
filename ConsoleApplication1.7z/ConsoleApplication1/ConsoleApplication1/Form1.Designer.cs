﻿namespace ConsoleApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnjouer = new System.Windows.Forms.Button();
            this.btnManger = new System.Windows.Forms.Button();
            this.btnDormir = new System.Windows.Forms.Button();
            this.btnNettoyer = new System.Windows.Forms.Button();
            this.ecran = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.ecran)).BeginInit();
            this.SuspendLayout();
            // 
            // btnjouer
            // 
            this.btnjouer.Location = new System.Drawing.Point(21, 65);
            this.btnjouer.Name = "btnjouer";
            this.btnjouer.Size = new System.Drawing.Size(94, 59);
            this.btnjouer.TabIndex = 0;
            this.btnjouer.Text = "Jouer";
            this.btnjouer.UseVisualStyleBackColor = true;
            // 
            // btnManger
            // 
            this.btnManger.Location = new System.Drawing.Point(23, 251);
            this.btnManger.Name = "btnManger";
            this.btnManger.Size = new System.Drawing.Size(91, 61);
            this.btnManger.TabIndex = 1;
            this.btnManger.Text = "manger";
            this.btnManger.UseVisualStyleBackColor = true;
            // 
            // btnDormir
            // 
            this.btnDormir.Location = new System.Drawing.Point(403, 67);
            this.btnDormir.Name = "btnDormir";
            this.btnDormir.Size = new System.Drawing.Size(87, 56);
            this.btnDormir.TabIndex = 2;
            this.btnDormir.Text = "dormir";
            this.btnDormir.UseVisualStyleBackColor = true;
            this.btnDormir.Click += new System.EventHandler(this.btnDormir_Click);
            // 
            // btnNettoyer
            // 
            this.btnNettoyer.Location = new System.Drawing.Point(401, 246);
            this.btnNettoyer.Name = "btnNettoyer";
            this.btnNettoyer.Size = new System.Drawing.Size(88, 65);
            this.btnNettoyer.TabIndex = 3;
            this.btnNettoyer.Text = "nettoyer";
            this.btnNettoyer.UseVisualStyleBackColor = true;
            // 
            // ecran
            // 
            this.ecran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ecran.Location = new System.Drawing.Point(171, 71);
            this.ecran.Name = "ecran";
            this.ecran.Size = new System.Drawing.Size(190, 240);
            this.ecran.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 411);
            this.Controls.Add(this.ecran);
            this.Controls.Add(this.btnNettoyer);
            this.Controls.Add(this.btnDormir);
            this.Controls.Add(this.btnManger);
            this.Controls.Add(this.btnjouer);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.ecran)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnjouer;
        private System.Windows.Forms.Button btnManger;
        private System.Windows.Forms.Button btnDormir;
        private System.Windows.Forms.Button btnNettoyer;
        private System.Windows.Forms.DataGridView ecran;
    }
}