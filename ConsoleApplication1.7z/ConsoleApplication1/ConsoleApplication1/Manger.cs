﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class manger : Action
    {
        public manger()
        : base()
        {
            if (this.manger < 0)
            {
                this.vie--;
            }
            else if (this.manger > 4)
            {
                this.vie++;
            }
            
        }
    }
}