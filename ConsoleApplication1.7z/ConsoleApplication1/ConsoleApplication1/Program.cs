﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Timer timer = new Timer(1000);
            Action action = new Action();
            Console.WriteLine(Action.ToString());
            Console.ReadLine();
        }
    }
}
