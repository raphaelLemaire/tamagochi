﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace ConsoleApplication1
{
    class CAD
    {
        public class Cad
        {
            private String cnx;
            private String rq_sql;
            private SqlDataAdapter DataAdapter;
            private SqlConnection Connection;
            private SqlCommand Command;
            private DataSet DataSet;
        }
        public CAD()
        {
            this.cnx = "";
            this.rq_sql = "";
            this.Connection = new SqlConnection(this.cnx);
            this.Command = null;
            this.DataAdapter = null;
            this.DataSet = new DataSet();

        }
    }
    public void actionRows(String rq_sql)
    {
        this.rq_sql = rq_sql;
        this.Command = new SqlCommand(rq_sql, Connection);
        this.Connection.Open();
        this.Command.ExecuteNonQuery();
        this.Connection.Close();
    }
}
}
