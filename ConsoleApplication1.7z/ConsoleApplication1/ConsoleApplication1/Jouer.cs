﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class jouer : Action 
    {
        public jouer() 
        : base()        
        {
          if (this.jouer <0)
            {
                this.vie--;
            }
    }
  }
}

